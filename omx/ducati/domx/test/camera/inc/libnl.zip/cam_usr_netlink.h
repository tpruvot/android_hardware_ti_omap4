struct cam_msg_hdr_def {
	uint cam_fh;
};

struct cam_handle_ref {
	int cam_family_id;
/* keep on adding the members in this struct which are common accross the 
 * open call received
 */
	struct nl_sock *sock;
	struct cam_msg_hdr_def cam_hdr; 

};

#define CAM_HDR_SIZE sizeof(struct cam_msg_hdr_def)

enum ioctl_param {
	CAM_ATTR_UNSPEC,
	CAM_ATTR_ERROR,
	CAM_ATTR_FMT,
	CAM_ATTR_REQ_BUF,
	CAM_ATTR_QBUF,
	CAM_ATTR_STRM_ON,
	CAM_ATTR_STRM_OFF,
	CAM_ATTR_DQBUF,
	CAM_ATTR_TEST_ECHO,
	_CAM_ATTR_MAX,
};

#define CAM_ATTR_MAX  (_CAM_ATTR_MAX)

enum format_param{
	CAM_ATTR_FMT_UNSPEC,
	CAM_ATTR_FMT_IMG_WIDTH,
	CAM_ATTR_FMT_IMG_HEIGHT,
	CAM_ATTR_FMT_IMG_PIXFMT,
	CAM_ATTR_FMT_IMG_BPL,
	CAM_ATTR_FMT_IMGSIZE,
	__CAM_ATTR_FMT_MAX
};


#define CAM_ATTR_FMT_MAX (__CAM_ATTR_FMT_MAX)

enum reqbuf_param {
	CAM_ATTR_RBUF_UNSPEC,
	CAM_ATTR_RBUF_CNT,
	CAM_ATTR_RBUF_BSIZE,
	CAM_ATTR_RBUF_MTYPE,
	CAM_ATTR_RBUF_PARAM,
	__CAM_ATTR_RBUF_MAX
};
#define CAM_ATTR_RBUF_MAX (__CAM_ATTR_FMT_MAX)

enum vb_param {
	CAM_ATTR_VB_UNSPEC,
	CAM_ATTR_VB_INDEX,
	CAM_ATTR_VB_START,
	CAM_ATTR_VB_BPL,
	CAM_ATTR_VB_SIZE,
	__CAM_ATTR_VB_MAX
};

#define CAM_ATTR_VB_MAX (__CAM_ATTR_VB_MAX)

enum qbuf_param {
	CAM_ATTR_QBUF_UNSPEC,
	CAM_ATTR_QBUF_INDEX,
	CAM_ATTR_QBUF_ERR,
	__CAM_ATTR_QBUF_MAX
};

#define CAM_ATTR_QBUF_MAX (__CAM_ATTR_QBUF_MAX)

enum dqbuf_param {
	CAM_ATTR_DQBUF_UNSPEC,
	CAM_ATTR_DQBUF_INDEX,
	CAM_ATTR_DQBUF_ERR,
	__CAM_ATTR_DQBUF_MAX
};

#define CAM_ATTR_DQBUF_MAX  (__CAM_ATTR_QBUF_MAX)



enum {
	CAM_CMD_UNSPEC,
	CAM_CMD_PID_REGISTER,  //1
	CAM_CMD_OPEN, //2
	CAM_CMD_S_FMT, //3
	CAM_CMD_TEST_ECHO, //4
	CAM_CMD_CROPCAP, //5
	CAM_CMD_G_CROP, //6
	CAM_CMD_S_CROP, //7
	CAM_CMD_G_CTRL, //8
	CAM_CMD_S_CTRL, //9
	CAM_CMD_G_PARAM, //10
	CAM_CMD_S_PARAM, //11
	CAM_CMD_STRM_ON, //12
	CAM_CMD_STRM_OFF, //13
	CAM_CMD_G_INPUT, //14
	CAM_CMD_S_INPUT, //15
	CAM_CMD_MMAP, //16
	CAM_CMD_REQ_BUF, //17
	CAM_CMD_QBUF, //18
	CAM_CMD_DQBUF, //19
	CAM_CMD_CLOSE, //1
	_CAM_CMD_MAX,
};

#define CAM_CMD_MAX (_CAM_CMD_MAX)

#define CAM_MAX_CMD_OPS 2
struct nla_policy cam_cmd_policy[CAM_ATTR_MAX +1] = {
	[CAM_ATTR_FMT] = { .type=NLA_NESTED },
	[CAM_ATTR_TEST_ECHO] = {.type = NLA_STRING}
};

